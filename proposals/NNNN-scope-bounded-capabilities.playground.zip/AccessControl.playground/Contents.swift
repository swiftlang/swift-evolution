//: Playground - noun: a place where people can play

import UIKit


// MARK: Scopes

// Scopes form a strict hierarchy from everywhere (including outside the module) all the way down to the narrowest lexical scope and then to nowhere.
// Scopes that receive user-defined identifiers in Swift code are referenced using their identifier name.
// Only the names of ancestor scopes may be referenced.
// The language also provides constants for several context-sensitive scope references as seen below.
struct Scope: CustomDebugStringConvertible {
    let name: String
    var debugDescription: String {
        return name
    }
    // A compiler defined value meaning outside the module.
    static let everywhere = Scope(name: "everywhere")
    
    // A compiler defined value meaning inside the module.
    static let module = Scope(name: "module")
    
    // Ancestor submodule names fit into the hierarchy here.
    
    // A compiler defined value meaning inside the submodule.
    static let submodule = Scope(name: "submodule")
    
    // A compiler defined value meaning inside the current file.
    static let file = Scope(name: "file")
    
    // Ancestor lexical scopes (type names) fit into the hierarchy here.

    // A compiler defined value meaning the extension in which the declaration occurs.
    static let `extension` = Scope(name: "extension")
    
    // A compiler defined value meaning the lexical scope in which the declaration occurs.
    static let lexical = Scope(name: "lexical")

    // A compiler defined value meaning no scopes at all.
    static let nowhere = Scope(name: "nowhere")
    
    // The default scope when a capability is not bounded by an explicit access modifier.
    static let `default` = submodule // or module like in Swift 3
}

// Syntactic sugar to avoid the `.` prefix, more closely modeling the real access modifier syntax
let everywhere = Scope.everywhere
let module = Scope.module
let submodule = Scope.submodule
let `extension` = Scope.extension
let file = Scope.file
let lexical = Scope.lexical
let nowhere = Scope.nowhere




// MARK: Capabilities

// Capability specifiers all conform to this protocol.
protocol CapabilityProtocol: Hashable {
    // The basic capability is referenced by an access modifier if none is explicitly stated.
    // All other capabilities are implicitly bounded by the scope of the basic capability.
    static var basic: Self { get }
}

enum PropertyCapability: CapabilityProtocol {
    case get
    case set // only valid for readwrite properties
    case override // only valid for subclass properties
    static let basic = PropertyCapability.get
}

enum FunctionCapability: CapabilityProtocol {
    case call
    case override // only valid for class methods
    
    static let basic = FunctionCapability.call
}

enum TypeCapability: CapabilityProtocol {
    case use
    case inherit // only valid for classes
    case exhaustiveSwitch // only valid for enums
    static let basic = TypeCapability.use
}

enum ProtocolCapability: CapabilityProtocol {
    case use
    case conform

    static let basic = ProtocolCapability.use
}

// For declarations with no additional capabilities
enum BasicCapability: CapabilityProtocol {
    case use
    static let basic = BasicCapability.use
}



// MARK: Scope-bounded capabilities

// All capabilities are implicilty bounded by (sub)module scope (except setters which implicitly match the getter).
// Explicit access modifier expressions are used to modify that default.
// These expressions have a CapabilityBound type.
// The type of `Capability` is specified by each kind of declaration.
struct CapabilityBound <Capability: CapabilityProtocol>: CustomDebugStringConvertible {
    let capability: Capability
    let scope: Scope
    var debugDescription: String {
        return "CapabilityBound<\(Capability.self)>: The scope of \(capability) is \(scope)"
    }
}

// The `access` function has overloads with and without labels.
// The final syntax could be decided by community bikeshedding.
func access<Capability: CapabilityProtocol>(to capability: Capability = .basic, is scope: Scope) -> CapabilityBound<Capability> {
    return CapabilityBound(capability: capability, scope: scope)
}
func access<Capability: CapabilityProtocol>(_ capability: Capability = .basic, _ scope: Scope) -> CapabilityBound<Capability> {
    return CapabilityBound(capability: capability, scope: scope)
}
func access<Capability: CapabilityProtocol>(_ scope: Scope) -> CapabilityBound<Capability> {
    return CapabilityBound(capability: Capability.basic, scope: scope)
}


// equivalent to `private` in Swift 3
func scoped<Capability: CapabilityProtocol>(_ capability: Capability = .basic) -> CapabilityBound<Capability> {
    return access(to: capability, is: lexical)
}
func `private`<Capability: CapabilityProtocol>(_ capability: Capability = .basic) -> CapabilityBound<Capability> {
    // or access(to: capability, is: current) like in Swift 3
    return access(to: capability, is: file)
}
func `fileprivate`<Capability: CapabilityProtocol>(_ capability: Capability = .basic) -> CapabilityBound<Capability> {
    return access(to: capability, is: file)
}
func `internal`<Capability: CapabilityProtocol>(_ capability: Capability = .basic) -> CapabilityBound<Capability> {
    // or access(to: capability, is: module) like in Swift 3
    return access(to: capability, is: submodule)
}
func`public`<Capability: CapabilityProtocol>(_ capability: Capability = .basic) -> CapabilityBound<Capability> {
    return access(to: capability, is: everywhere)
}


let final: CapabilityBound<TypeCapability> = access(to: .inherit, is: nowhere)
let open: CapabilityBound<TypeCapability> = access(to: .inherit, is: everywhere)

// Duplicate symbol definitions are not a problem in practice 
// because only one definition will be relevant to the context of an access modifier.
// The previous definitions apply to classes, the commented out definitions apply to members.

//let final: CapabilityBound<FunctionCapability> = access(to: .inherit, is: nowhere)
//let open: CapabilityBound<FunctionCapability> = access(to: .inherit, is: everywhere)

let closed: CapabilityBound<TypeCapability> = access(to: .exhaustiveSwitch, is: everywhere)
